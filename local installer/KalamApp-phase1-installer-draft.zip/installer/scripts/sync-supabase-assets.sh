#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
INSTALLER="$ROOT/installer"
REF="${1:-}"
[[ -n "$REF" ]] || { echo 'Usage: scripts/sync-supabase-assets.sh <official-supabase-commit-or-tag>' >&2; exit 2; }
command -v git >/dev/null; command -v python3 >/dev/null
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
cd "$TMP"; git init -q; git remote add origin https://github.com/supabase/supabase.git
git fetch --depth 1 origin "$REF" >/dev/null 2>&1
git checkout -q FETCH_HEAD
python3 - "$ROOT/docker-compose.yml" "$TMP/docker/docker-compose.yml" <<'PY'
import re,sys
from pathlib import Path
def pins(path):
 return sorted(x for x in re.findall(r'^\s*image:\s*([^\s]+)',Path(path).read_text(),re.M) if x.startswith('supabase/'))
a,b=pins(sys.argv[1]),pins(sys.argv[2])
if a!=b:
 print('BLOCKED: official Compose image pins do not exactly match central repository Compose. No installer files changed.')
 print('central:',a); print('upstream:',b); raise SystemExit(3)
print('PASS: all Supabase image pins match.')
PY
# Stage vendor files and a refreshed customer Compose before replacing current artifacts.
STAGE="$INSTALLER/docker/.volumes-sync"
rm -rf "$STAGE"; cp -a "$TMP/docker/volumes" "$STAGE"
cp -a "$ROOT/supabase/functions/." "$STAGE/functions/"
python3 - "$ROOT/docker-compose.yml" "$INSTALLER/docker/docker-compose.customer.yml" "$INSTALLER/UPSTREAM.json" "$TMP" <<'PY'
import json,re,subprocess,sys
from pathlib import Path
central=Path(sys.argv[1]).read_text(encoding='utf-8')
old=Path(sys.argv[2]).read_text(encoding='utf-8')
if 'KALAM_AUTH_SMS_HOOK_URI' not in central:
 if 'GOTRUE_HOOK_SEND_SMS_URI:' not in central:
  raise SystemExit('BLOCKED: central SMS Hook setting not found; no installer files updated.')
 central=re.sub(r'(?m)^(\s*)GOTRUE_HOOK_SEND_SMS_URI:.*$',r'\1GOTRUE_HOOK_SEND_SMS_URI: "${KALAM_AUTH_SMS_HOOK_URI:-http://kong:8000/functions/v1/send-sms}?hook_secret=${KALAM_AUTH_SMS_HOOK_SECRET}"',central)
 central=re.sub(r'(?m)^(\s*)GOTRUE_HOOK_SEND_SMS_ENABLED:.*$',r'\1GOTRUE_HOOK_SEND_SMS_ENABLED: "${KALAM_AUTH_SMS_HOOK_ENABLED:-false}"',central)
central=central.replace('    ports:\n      - ${KONG_HTTP_PORT}:8000/tcp\n      - ${KONG_HTTPS_PORT}:8443/tcp','    expose:\n      - "8000"\n      - "8443"')
if '      - ${KONG_HTTP_PORT}:8000/tcp' in central or '    ports:\n    expose:' in central:
 raise SystemExit('BLOCKED: Kong mapping could not be made private; no installer files updated.')
# Remove the central-only host-gateway entry from the auth service.
auth=re.search(r'(?ms)^  auth:\n.*?(?=^  [A-Za-z0-9_-]+:\n|^volumes:\n)',central)
if auth:
 block=re.sub(r'(?m)^    extra_hosts:\n(?:^      -.*\n)+','',auth.group(0))
 central=central[:auth.start()]+block+central[auth.end():]
# Reapply dedicated project environment variables used by copied edge functions.
function_env={
 'AI_API_KEY':'${AI_API_KEY}','AI_BASE_URL':'${AI_BASE_URL}','AI_FALLBACK_BASE_URLS':'${AI_FALLBACK_BASE_URLS}',
 'AI_PROVIDER':'${AI_PROVIDER}','AI_SERVICE_TIER':'${AI_SERVICE_TIER}','APP_ORIGIN':'${APP_ORIGIN}',
 'AVALAI_FALLBACK_BASE_URL':'${AVALAI_FALLBACK_BASE_URL}','AVALAI_MODEL':'${AVALAI_MODEL}',
 'AVALAI_PROVIDER':'${AVALAI_PROVIDER}','AVALAI_SERVICE_TIER':'${AVALAI_SERVICE_TIER}',
 'BOT_WEBHOOK_PUBLIC_BASE_URL':'${BOT_WEBHOOK_PUBLIC_BASE_URL}','EXTERNAL_SUPABASE_URL':'${EXTERNAL_SUPABASE_URL}',
 'FILE_STORAGE_BUCKET':'${FILE_STORAGE_BUCKET}','KALAMAPP_PUBLIC_BASE_URL':'${KALAMAPP_PUBLIC_BASE_URL}',
 'MELIPAYAMAK_INBOUND_SECRET':'${MELIPAYAMAK_INBOUND_SECRET}','OPENAI_API_KEY':'${OPENAI_API_KEY}',
 'PAYMENT_CALLBACK_PATH':'${PAYMENT_CALLBACK_PATH}','PAYMENT_PUBLIC_URL':'${PAYMENT_PUBLIC_URL}',
 'PUBLIC_API_BASE_URL':'${PUBLIC_API_BASE_URL}','PUBLIC_APP_URL':'${PUBLIC_APP_URL}',
 'PUBLIC_FUNCTIONS_URL':'${PUBLIC_FUNCTIONS_URL}','PUBLIC_SUPABASE_URL':'${PUBLIC_SUPABASE_URL}',
 'RUBIKA_RAW_HTTP_FALLBACK':'${RUBIKA_RAW_HTTP_FALLBACK}','SMS_MARGIN_PERCENT':'${SMS_MARGIN_PERCENT}',
 'SUPABASE_PUBLIC_URL':'${SUPABASE_PUBLIC_URL}','TAXPAYER_SECRET_ENCRYPTION_KEY':'${TAXPAYER_SECRET_ENCRYPTION_KEY}',
 'TELEFONCHY_BASE_URL':'${TELEFONCHY_BASE_URL}','TELEFONCHY_SERVICE_ID':'${TELEFONCHY_SERVICE_ID}',
 'TELEFONCHY_WEBHOOK_SECRET':'${TELEFONCHY_WEBHOOK_SECRET}','TELEFONCHY_WEBSERVICE_TOKEN':'${TELEFONCHY_WEBSERVICE_TOKEN}',
 'VITE_FILE_STORAGE_BUCKET':'${VITE_FILE_STORAGE_BUCKET}','VITE_SUPABASE_URL':'${VITE_SUPABASE_URL}',
 'WORKFLOW_CRON_SECRET':'${WORKFLOW_CRON_SECRET}','ZARINPAL_MODE':'${ZARINPAL_MODE}'}
fm=re.search(r'(?ms)^  functions:\n.*?(?=^  [A-Za-z0-9_-]+:\n|^volumes:\n)',central)
if not fm: raise SystemExit('BLOCKED: functions service not found; no installer files updated.')
fb=fm.group(0); em=re.search(r'(?ms)^    environment:\n(.*?)(?=^    command:\n)',fb)
if not em: raise SystemExit('BLOCKED: functions environment block not found; no installer files updated.')
mapped=set(re.findall(r'(?m)^      ([A-Z][A-Z0-9_]*):',em.group(1)))
extra=''.join(f'      {k}: {v}\n' for k,v in function_env.items() if k not in mapped)
fb=fb[:em.end(1)]+extra+fb[em.end(1):]
central=central[:fm.start()]+fb+central[fm.end():]
m=re.search(r'(?ms)^  customer-frontend:\n.*?(?=^volumes:\n)',old)
if not m: raise SystemExit('BLOCKED: dedicated frontend service block not found; no installer files updated.')
front=m.group(0).replace('      - ${FRONTEND_HTTP_PORT:-8080}:80','      - 127.0.0.1:${FRONTEND_HTTP_PORT:-8080}:80')
if '\nvolumes:\n' not in central: raise SystemExit('BLOCKED: central Compose has no top-level volumes section.')
central=central.replace('\nvolumes:\n','\n'+front.rstrip()+'\n\nvolumes:\n',1)
Path(sys.argv[2]+'.new').write_text(central,encoding='utf-8',newline='\n')
tmp=Path(sys.argv[4]); upstream=(tmp/'docker/docker-compose.yml').read_text()
images=re.findall(r'^\s*image:\s*(supabase/[^\s]+)',upstream,re.M)
obj={'repository':'https://github.com/supabase/supabase','commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=tmp,text=True).strip(),'matching_image_pins':images,'policy':'All Supabase image pins must match root docker-compose.yml before refreshing installer assets.'}
Path(sys.argv[3]+'.new').write_text(json.dumps(obj,indent=2)+'\n',encoding='utf-8',newline='\n')
PY
mv "$INSTALLER/docker/docker-compose.customer.yml.new" "$INSTALLER/docker/docker-compose.customer.yml"
mv "$INSTALLER/UPSTREAM.json.new" "$INSTALLER/UPSTREAM.json"
rm -rf "$INSTALLER/docker/volumes.old"
[[ ! -d "$INSTALLER/docker/volumes" ]] || mv "$INSTALLER/docker/volumes" "$INSTALLER/docker/volumes.old"
mv "$STAGE" "$INSTALLER/docker/volumes"
rm -rf "$INSTALLER/docker/volumes.old"
echo 'Updated official assets and customer Compose after exact image-pin validation. Review the diff and test before packaging.'
