#!/usr/bin/env bash
set -euo pipefail
ENV_FILE="${1:-${KALAMAPP_ENV_FILE:-$HOME/.config/kalamapp/customer.env}}"
fail=0
need(){ command -v "$1" >/dev/null 2>&1 || { echo "FAIL: required command unavailable: $1"; fail=1; }; }
need docker; need openssl; need python3; need curl
if command -v docker >/dev/null 2>&1; then docker compose version >/dev/null 2>&1 || { echo 'FAIL: Docker Compose v2 plugin unavailable'; fail=1; }; fi
[[ "$(uname -s)" == Linux ]] || { echo 'FAIL: supported target is Linux'; fail=1; }
[[ -f "$ENV_FILE" ]] || { echo "FAIL: environment file missing: $ENV_FILE"; fail=1; }
if [[ -f "$ENV_FILE" ]] && ! grep -q '^CUSTOMER_PUBLIC_URL=https://' "$ENV_FILE"; then
  echo 'FAIL: set CUSTOMER_PUBLIC_URL to the final HTTPS origin.'; fail=1
fi
if [[ $fail -eq 0 ]]; then echo 'PASS: prerequisite commands and configuration file detected.'; fi
exit "$fail"
