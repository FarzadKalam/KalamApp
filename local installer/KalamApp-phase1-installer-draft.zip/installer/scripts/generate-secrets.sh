#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ENV_FILE="${1:-${KALAMAPP_ENV_FILE:-$HOME/.config/kalamapp/customer.env}}"
[[ -f "$ENV_FILE" ]] || { echo "Missing $ENV_FILE. Copy config/customer.env.example first." >&2; exit 2; }
python3 - "$ENV_FILE" <<'PY'
import base64,hashlib,hmac,json,secrets,sys,time
from pathlib import Path
p=Path(sys.argv[1]); lines=p.read_text(encoding='utf-8').splitlines()
values={}
for line in lines:
 if '=' in line and not line.lstrip().startswith('#'):
  k,v=line.split('=',1); values[k.strip()]=v.strip().strip('"')
secret_names={'POSTGRES_PASSWORD','JWT_SECRET','DASHBOARD_PASSWORD','SECRET_KEY_BASE','VAULT_ENC_KEY','PG_META_CRYPTO_KEY','LOGFLARE_PUBLIC_ACCESS_TOKEN','LOGFLARE_PRIVATE_ACCESS_TOKEN','S3_PROTOCOL_ACCESS_KEY_ID','S3_PROTOCOL_ACCESS_KEY_SECRET','MINIO_ROOT_PASSWORD','INSTAGRAM_SECRET_ENCRYPTION_KEY','INTEGRATION_SECRET_ENCRYPTION_KEY','KALAM_AUTH_SMS_HOOK_SECRET','TAXPAYER_SECRET_ENCRYPTION_KEY','MELIPAYAMAK_INBOUND_SECRET','TELEFONCHY_WEBHOOK_SECRET','WORKFLOW_CRON_SECRET'}
required={'POSTGRES_PASSWORD','JWT_SECRET','DASHBOARD_PASSWORD','SECRET_KEY_BASE','VAULT_ENC_KEY','PG_META_CRYPTO_KEY','LOGFLARE_PUBLIC_ACCESS_TOKEN','LOGFLARE_PRIVATE_ACCESS_TOKEN','ANON_KEY','SERVICE_ROLE_KEY'}
filled={k for k in required if values.get(k)}
if filled:
 if required <= filled:
  print('Secrets already exist; left unchanged.'); raise SystemExit(0)
 raise SystemExit('Partial secret set found; refusing to rotate or overwrite. Restore a complete .env or use a fresh copy.')
def b64(x): return base64.urlsafe_b64encode(x).decode().rstrip('=')
def jwt(role,key):
 h=b64(json.dumps({'alg':'HS256','typ':'JWT'},separators=(',',':')).encode())
 pl=b64(json.dumps({'role':role,'iss':'supabase','iat':int(time.time()),'exp':int(time.time())+5*365*86400},separators=(',',':')).encode())
 msg=f'{h}.{pl}'.encode(); sig=b64(hmac.new(key.encode(),msg,hashlib.sha256).digest())
 return f'{h}.{pl}.{sig}'
new={k:secrets.token_hex(32) for k in secret_names}
new['JWT_SECRET']=secrets.token_urlsafe(48)
new['DASHBOARD_PASSWORD']='K'+secrets.token_urlsafe(24).replace('-','A').replace('_','B')
new['ANON_KEY']=jwt('anon',new['JWT_SECRET']); new['SERVICE_ROLE_KEY']=jwt('service_role',new['JWT_SECRET'])
url=values.get('CUSTOMER_PUBLIC_URL','').rstrip('/')
if not url.startswith('https://'):
 raise SystemExit('Set CUSTOMER_PUBLIC_URL to the final HTTPS origin before generating secrets.')
new.update({'SUPABASE_PUBLIC_URL':url,'API_EXTERNAL_URL':url+'/auth/v1','SITE_URL':url,'APP_ORIGIN':url,'KALAMAPP_PUBLIC_BASE_URL':url,'PAYMENT_PUBLIC_URL':url,'PUBLIC_API_BASE_URL':url,'PUBLIC_APP_URL':url,'PUBLIC_FUNCTIONS_URL':url+'/functions/v1','PUBLIC_SUPABASE_URL':url,'SUPABASE_URL':url,'VITE_SUPABASE_URL':url,'EXTERNAL_SUPABASE_URL':url,'BOT_WEBHOOK_PUBLIC_BASE_URL':url})
for k,v in new.items():
 found=False; out=[]
 for line in lines:
  if line.startswith(k+'='): out.append(k+'='+v); found=True
  else: out.append(line)
 if not found: out.append(k+'='+v)
 lines=out
p.write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n'); p.chmod(0o600)
print('Generated per-install secrets and JWT API keys. Values were not printed.')
PY
