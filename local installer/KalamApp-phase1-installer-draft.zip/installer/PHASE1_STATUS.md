# وضعیت پیش‌نویس فاز اول

- منبع Compose: `docker-compose.yml` فعلی مخزن، کپی‌شده به `docker/docker-compose.customer.yml`.
- فایل‌های رسمی Supabase: commit `61905186409ae82ef109d961805ff15d8ff703f6`; هر ۹ image pin با Compose موجود در مخزن تطبیق داده و sync همان commit آزمایش شد. نسخهٔ deployشده روی سرور مرکزی بررسی نشده است.
- تغییر در ریشه یا فایل‌های core: هیچ‌کدام.
- SMS central hook: در نسخه اختصاصی خاموش و URL/secret قابل‌تنظیم شده؛ Compose مرکزی دست‌نخورده.
- Secrets: نمونه در `config/customer.env.example` بدون Secret است؛ تولید به `$HOME/.config/kalamapp/customer.env` خارج Repository انجام می‌شود؛ آزمون JWT و idempotence موفق.
- migration: BLOCKED؛ ۶۶۵ فایل SQL فهرست شدند، اما ترتیب bootstrapping/upgrade تأیید نشده؛ `migrate.sh` فقط inventory می‌دهد و apply نمی‌کند.
- Hard-code audit: انجام شد؛ چند Function هنوز central fallback/domain allow-list ثابت دارد. موارد High در `docs/HARD_CODE_AUDIT_FA.md` باعث می‌شود ماژول‌های متناظر تا تست یا مجوز تغییر کد Production-ready نباشند.
- TLS: نیازمند reverse proxy/customer certificate provisioning؛ این بسته گواهی صادر/تمدید نمی‌کند.
- آزمون ایستا: YAML parse، تطبیق image tagها، پوشش interpolationهای Compose، Bash syntax و تولید/امضای JWT آزمایش شدند؛ همهٔ ۶۲ نام env استفاده‌شده در Functionها به Compose وصل‌اند.
- آزمون شبیه‌سازی‌شده: backup/checksum/redaction، Health Check و مسیر فایل Restore با دادهٔ ساختگی و Docker stub اجرا شدند؛ این‌ها تست DB یا deployment واقعی نیستند.
- نصب Docker، DB، Restore واقعی و تست ماژول‌به‌ماژول: انجام نشده؛ Docker در محیط توسعه موجود نیست.
- Commit/Push/Deploy: انجام نشده.
