# راهنمای عملیات بسته اختصاصی

## وضعیت

این بسته هنوز برای production پذیرفته نشده است. Compose و assetها نسخه‌قفل‌اند؛ Docker در محیط بررسی موجود نبود، پس نصب روی Ubuntu تمیز و Restore واقعی اجرا نشد. migration از صفر، صحت OTP/SMS، Storage، Realtime، Edge Functions، TLS و وابستگی‌های ثابت گزارش‌شده در `HARD_CODE_AUDIT_FA.md` هنوز باید جداگانه تأیید شوند.

## فرمان‌های عملیاتی

از پوشه `installer` اجرا کنید:

```bash
./healthcheck.sh
./backup.sh
./restore.sh /path/to/backup-directory
```

فایل تنظیمات در `$HOME/.config/kalamapp/customer.env` نگهداری می‌شود؛ مسیر جایگزین را می‌توان با `KALAMAPP_ENV_FILE` داد. Backup پیش‌فرض در `$HOME/.local/share/kalamapp/backups` ایجاد می‌شود و config آن فقط به شکل redacted در آرشیو می‌آید. برای وضعیت کانتینرها از `docker compose --env-file "$HOME/.config/kalamapp/customer.env" -f docker/docker-compose.customer.yml ps` استفاده کنید. مقادیر config، کلیدها و logهای حاوی Secret را در ticket یا گزارش عمومی نگذارید. `healthcheck.sh` وضعیت Frontend، DB، Auth، REST، Realtime، Storage و Functions را جداگانه چاپ می‌کند؛ endpointهای بیرونی فقط با `EXTERNAL_HEALTH_CHECK_URLS` تنظیم می‌شوند و قطعی آن‌ها خرابی DB محسوب نمی‌شود.

## به‌روزرسانی Supabase

`UPSTREAM.json` مرجع نسخه است. پس از تغییر image pinهای Compose مرکزی، commit/tag رسمی متناظر را به `scripts/sync-supabase-assets.sh` بدهید. اسکریپت پیش از جایگزینی assetها، همه Supabase image pinها را دقیقاً تطبیق می‌دهد و در صورت اختلاف متوقف می‌شود. همگام‌سازی با pin فعلی آزمایش شد؛ نسخهٔ آینده هنوز آزمایش نشده است. هرگز `latest` را جایگزین pin نکنید.

## Rollback

پیش از ارتقای image، backup معتبر دیتابیس و storage بگیرید. نسخه قبلی Compose و commit رسمی را ثبت کنید. تا زمان آزمون restore، ارتقا روی داده مشتری اجرا نشود.
