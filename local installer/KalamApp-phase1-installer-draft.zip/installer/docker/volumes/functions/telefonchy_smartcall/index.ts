// @ts-nocheck

import { parseTehranProviderDateTimeToUtcIso } from '../_shared/tehran-datetime.ts';

const FUNCTION_BUILD = 'telefonchy-smartcall-2026-09-16-call-outcome-and-target';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

const json = (status: number, payload: Record<string, any>) =>
  new Response(JSON.stringify({ build: FUNCTION_BUILD, ...payload }), {
    status,
    headers: {
      ...corsHeaders,
      'Content-Type': 'application/json',
      'X-Kalam-Function-Build': FUNCTION_BUILD,
    },
  });

const getServiceHeaders = (serviceRoleKey: string) => ({
  apikey: serviceRoleKey,
  Authorization: `Bearer ${serviceRoleKey}`,
  'Content-Type': 'application/json',
});

const parseJsonSafe = (raw: string) => {
  try {
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
};

const firstValue = (...values: any[]) => {
  for (const value of values) {
    if (value === false) continue;
    if (value !== null && typeof value === 'object') continue;
    const normalized = String(value ?? '').trim();
    if (normalized) return normalized;
  }
  return '';
};

const normalizePhone = (value: any) =>
  String(value || '')
    .trim()
    .replace(/[\u200e\u200f\s().-]/g, '');

const trimTrailingSlash = (value: string) => String(value || '').replace(/\/+$/, '');

const pad2 = (value: number) => String(value).padStart(2, '0');

const gregorianToJalali = (date: Date) => {
  const div = (a: number, b: number) => Math.floor(a / b);
  const gDaysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const jDaysInMonth = [31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29];
  let gy = date.getFullYear() - 1600;
  let gm = date.getMonth();
  let gd = date.getDate() - 1;

  let gDayNo = 365 * gy + div(gy + 3, 4) - div(gy + 99, 100) + div(gy + 399, 400);
  for (let i = 0; i < gm; i += 1) gDayNo += gDaysInMonth[i];
  if (gm > 1 && ((gy + 1600) % 4 === 0 && ((gy + 1600) % 100 !== 0 || (gy + 1600) % 400 === 0))) {
    gDayNo += 1;
  }
  gDayNo += gd;

  let jDayNo = gDayNo - 79;
  const jNp = div(jDayNo, 12053);
  jDayNo %= 12053;
  let jy = 979 + 33 * jNp + 4 * div(jDayNo, 1461);
  jDayNo %= 1461;
  if (jDayNo >= 366) {
    jy += div(jDayNo - 1, 365);
    jDayNo = (jDayNo - 1) % 365;
  }

  let jm = 0;
  while (jm < 11 && jDayNo >= jDaysInMonth[jm]) {
    jDayNo -= jDaysInMonth[jm];
    jm += 1;
  }

  return { year: jy, month: jm + 1, day: jDayNo + 1 };
};

const formatTelefonchyJalaliDateTime = (date: Date, time: string) => {
  const jalali = gregorianToJalali(date);
  return `${jalali.year}/${pad2(jalali.month)}/${pad2(jalali.day)} ${time}`;
};

const verifyUserToken = async (supabaseUrl: string, serviceRoleKey: string, userToken: string) => {
  const response = await fetch(`${trimTrailingSlash(supabaseUrl)}/auth/v1/user`, {
    method: 'GET',
    headers: {
      apikey: serviceRoleKey,
      Authorization: `Bearer ${userToken}`,
    },
  });
  const raw = await response.text();
  if (!response.ok) throw new Error(raw || 'نشست شما معتبر نیست. دوباره وارد حساب کاربری شوید.');

  const user = parseJsonSafe(raw);
  if (!user?.id) throw new Error('نشست شما معتبر نیست. دوباره وارد حساب کاربری شوید.');
  return user;
};

const fetchProfile = async (supabaseUrl: string, serviceRoleKey: string, userId: string) => {
  const url = new URL(`${trimTrailingSlash(supabaseUrl)}/rest/v1/profiles`);
  url.searchParams.set('id', `eq.${userId}`);
  url.searchParams.set(
    'select',
    'id,org_id,full_name,voip_enabled,voip_operator_code,voip_extension,voip_service_id,voip_dial_mode'
  );
  url.searchParams.set('limit', '1');

  const response = await fetch(url.toString(), {
    method: 'GET',
    headers: getServiceHeaders(serviceRoleKey),
  });
  const raw = await response.text();
  if (!response.ok) throw new Error(raw || 'خواندن پروفایل VoIP ناموفق بود.');

  const rows = parseJsonSafe(raw) || [];
  return Array.isArray(rows) ? rows[0] : null;
};

const fetchVoipSettings = async (supabaseUrl: string, serviceRoleKey: string, orgId: string) => {
  const url = new URL(`${trimTrailingSlash(supabaseUrl)}/rest/v1/integration_settings`);
  url.searchParams.set('org_id', `eq.${orgId}`);
  url.searchParams.set('connection_type', 'eq.voip');
  url.searchParams.set('is_active', 'eq.true');
  url.searchParams.set('select', 'id,provider,settings,is_active');
  url.searchParams.set('limit', '10');

  const response = await fetch(url.toString(), {
    method: 'GET',
    headers: getServiceHeaders(serviceRoleKey),
  });
  const raw = await response.text();
  if (!response.ok) throw new Error(raw || 'خواندن تنظیمات VoIP ناموفق بود.');

  const rows = parseJsonSafe(raw) || [];
  if (!Array.isArray(rows) || rows.length === 0) return null;
  return rows.find((row) => String(row?.provider || '').toLowerCase() === 'telefonchy') || rows[0];
};

const fetchActiveTelefonchySettings = async (supabaseUrl: string, serviceRoleKey: string) => {
  const url = new URL(`${trimTrailingSlash(supabaseUrl)}/rest/v1/integration_settings`);
  url.searchParams.set('connection_type', 'eq.voip');
  url.searchParams.set('is_active', 'eq.true');
  url.searchParams.set('provider', 'eq.telefonchy');
  url.searchParams.set('select', 'org_id,provider,settings');
  url.searchParams.set('limit', '100');
  const response = await fetch(url.toString(), { headers: getServiceHeaders(serviceRoleKey) });
  const raw = await response.text();
  if (!response.ok) throw new Error(raw || 'خواندن اتصال‌های فعال تلفنچی ناموفق بود.');
  const rows = parseJsonSafe(raw);
  return Array.isArray(rows) ? rows : [];
};

const createTimeoutSignal = (timeoutMs: number) => {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(`timeout:${timeoutMs}`), timeoutMs);
  return {
    signal: controller.signal,
    cleanup: () => clearTimeout(timer),
  };
};

const insertCallLog = async (
  supabaseUrl: string,
  serviceRoleKey: string,
  row: Record<string, any>
) => {
  const insert = async (payload: Record<string, any>) => {
    const response = await fetch(`${trimTrailingSlash(supabaseUrl)}/rest/v1/voip_call_logs`, {
      method: 'POST',
      headers: {
        ...getServiceHeaders(serviceRoleKey),
        Prefer: 'return=representation',
      },
      body: JSON.stringify(payload),
    });
    const raw = await response.text();
    return { response, raw };
  };

  let result = await insert(row);
  if (!result.response.ok && /column .*title|schema cache/i.test(result.raw || '')) {
    const { title: _title, ...withoutTitle } = row;
    result = await insert(withoutTitle);
  }
  if (!result.response.ok) throw new Error(result.raw || 'ثبت گزارش تماس ناموفق بود.');

  const parsed = parseJsonSafe(result.raw);
  return Array.isArray(parsed) ? parsed[0] : parsed;
};

const extractProviderIds = (parsed: any) => {
  const source = parsed && typeof parsed === 'object' ? parsed : {};
  const callId = firstValue(
    source.call_id,
    source.callId,
    source.cuid,
    source.unique_id,
    source.id,
    source.data?.call_id,
    source.data?.callId,
    source.data?.cuid,
    source.data?.unique_id,
    source.data?.id
  );
  const objectId = firstValue(
    source.object_id,
    source.objectId,
    source.data?.object_id,
    source.data?.objectId,
    source.data?.id
  );

  return {
    callId: callId || '',
    objectId: objectId || '',
  };
};

const toIntegerOrNull = (value: any) => {
  const parsed = Number(String(value ?? '').trim());
  if (!Number.isFinite(parsed)) return null;
  return Math.max(0, Math.floor(parsed));
};

const jalaliToGregorian = (jy: number, jm: number, jd: number) => {
  const div = (a: number, b: number) => Math.floor(a / b);
  jy += 1595;
  let days = -355668 + (365 * jy) + (div(jy, 33) * 8) + div(((jy % 33) + 3), 4) + jd;
  days += jm < 7 ? (jm - 1) * 31 : ((jm - 7) * 30) + 186;

  let gy = 400 * div(days, 146097);
  days %= 146097;
  if (days > 36524) {
    gy += 100 * div(--days, 36524);
    days %= 36524;
    if (days >= 365) days += 1;
  }
  gy += 4 * div(days, 1461);
  days %= 1461;
  if (days > 365) {
    gy += div(days - 1, 365);
    days = (days - 1) % 365;
  }

  let gd = days + 1;
  const leap = (gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0;
  const monthDays = [0, 31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  let gm = 1;
  while (gm <= 12 && gd > monthDays[gm]) {
    gd -= monthDays[gm];
    gm += 1;
  }

  return { year: gy, month: gm, day: gd };
};

const toIsoOrNull = (value: any) => {
  const raw = String(value ?? '').trim();
  if (!raw) return null;
  const jalaliMatch = raw.match(/^(1[34]\d{2})[-/](\d{1,2})[-/](\d{1,2})(?:[ T](\d{1,2}):(\d{1,2})(?::(\d{1,2}))?)?/);
  if (jalaliMatch) {
    const [, jy, jm, jd, hh = '0', mm = '0', ss = '0'] = jalaliMatch;
    const g = jalaliToGregorian(Number(jy), Number(jm), Number(jd));
    return new Date(Date.UTC(g.year, g.month - 1, g.day, Number(hh), Number(mm), Number(ss))).toISOString();
  }
  const normalized = /^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}/.test(raw) ? raw.replace(' ', 'T') : raw;
  const date = new Date(normalized);
  if (Number.isNaN(date.getTime())) return null;
  return date.toISOString();
};

const mapDirection = (value: any) => {
  const raw = String(value || '').trim().toLowerCase();
  if (['incoming', 'inbound', 'in', 'ورودی'].includes(raw)) return 'incoming';
  if (['outgoing', 'outbound', 'out', 'خروجی'].includes(raw)) return 'outgoing';
  if (['internal', 'local', 'داخلی'].includes(raw)) return 'internal';
  return 'unknown';
};

const mapStatus = (value: any, talkSeconds: number | null) => {
  const raw = String(value || '').trim().toLowerCase();
  const compact = raw.replace(/[\s_-]+/g, '');

  // Telefonchy sends values such as "NO ANSWER". A zero-second call was not
  // answered even when the provider status contains the word "answer".
  if (talkSeconds !== null && talkSeconds <= 0) return 'missed';
  if (talkSeconds && talkSeconds > 0) return compact.includes('answer') ? 'answered' : 'completed';
  if (raw.includes('miss') || compact.includes('noanswer') || compact.includes('notanswered')) return 'missed';
  if (raw.includes('fail') || raw.includes('busy') || raw.includes('cancel') || raw.includes('reject')) return 'failed';
  if (raw.includes('ring')) return 'ringing';
  if (compact.includes('answer')) return 'answered';
  if (raw.includes('complete') || raw.includes('end') || raw.includes('ok') || raw.includes('success')) return 'completed';
  return 'unknown';
};

const hasTelefonchyRecording = (_item: Record<string, any>, callId: string, fileId: string) => Boolean(callId && fileId);

const telefonchyEndpoint = (item: Record<string, any>, side: 'source' | 'destination') => {
  const contact = item?.contact && typeof item.contact === 'object' && !Array.isArray(item.contact) ? item.contact : {};
  const value = side === 'source' ? contact?.call_source : contact?.call_dest;
  return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
};

const isTelefonchyExtensionEndpoint = (endpoint: Record<string, any>) =>
  String(endpoint?.type || '').trim().toLowerCase() === 'exten';

const resolveTelefonchyOperator = (item: Record<string, any>, direction: string) => {
  const exten = item?.exten && typeof item.exten === 'object' && !Array.isArray(item.exten) ? item.exten : {};
  const endpoint = direction === 'incoming'
    ? telefonchyEndpoint(item, 'destination')
    : telefonchyEndpoint(item, 'source');
  const operatorContact = isTelefonchyExtensionEndpoint(endpoint)
    ? endpoint
    : {};
  return {
    extension: firstValue(item.extension, item.operator_extension, exten.number),
    operatorCode: firstValue(item.operator_code, item.operatorCode, exten.exten_id, operatorContact.contact_id, exten.id),
    providerOperatorId: firstValue(operatorContact.contact_id, exten.exten_id, exten.id),
    displayName: firstValue(item.operator_name, item.operator_display_name, operatorContact.name, exten.name),
  };
};

const extractCallsArray = (value: any): any[] => {
  if (Array.isArray(value)) return value;
  const candidates = [
    value?.data,
    value?.calls,
    value?.items,
    value?.result,
    value?.results,
    value?.data?.calls,
    value?.data?.items,
    value?.data?.data,
  ];
  for (const candidate of candidates) {
    if (Array.isArray(candidate)) return candidate;
  }
  return [];
};

const findExistingCallLog = async (
  supabaseUrl: string,
  serviceRoleKey: string,
  orgId: string,
  provider: string,
  callId: string,
  objectId: string
) => {
  const query = async (field: 'call_id' | 'object_id', value: string) => {
    if (!value) return null;
    const url = new URL(`${trimTrailingSlash(supabaseUrl)}/rest/v1/voip_call_logs`);
    url.searchParams.set('org_id', `eq.${orgId}`);
    url.searchParams.set('provider', `eq.${provider}`);
    url.searchParams.set(field, `eq.${value}`);
    url.searchParams.set('select', 'id');
    url.searchParams.set('limit', '1');

    const response = await fetch(url.toString(), {
      method: 'GET',
      headers: getServiceHeaders(serviceRoleKey),
    });
    const raw = await response.text();
    if (!response.ok) throw new Error(raw || 'خواندن گزارش تماس ناموفق بود.');

    const rows = parseJsonSafe(raw);
    return Array.isArray(rows) ? rows[0] : null;
  };

  return (await query('call_id', callId)) || (await query('object_id', objectId));
};

const saveCallLog = async (
  supabaseUrl: string,
  serviceRoleKey: string,
  row: Record<string, any>
) => {
  const existing = await findExistingCallLog(
    supabaseUrl,
    serviceRoleKey,
    row.org_id,
    row.provider,
    String(row.call_id || ''),
    String(row.object_id || '')
  );

  const write = async (payload: Record<string, any>) => {
    const targetUrl = existing?.id
      ? `${trimTrailingSlash(supabaseUrl)}/rest/v1/voip_call_logs?id=eq.${existing.id}`
      : `${trimTrailingSlash(supabaseUrl)}/rest/v1/voip_call_logs`;
    const response = await fetch(targetUrl, {
      method: existing?.id ? 'PATCH' : 'POST',
      headers: {
        ...getServiceHeaders(serviceRoleKey),
        Prefer: 'return=representation',
      },
      body: JSON.stringify(payload),
    });
    const raw = await response.text();
    return { response, raw };
  };

  let result = await write(row);
  if (!result.response.ok && /column .*title|schema cache/i.test(result.raw || '')) {
    const { title: _title, ...withoutTitle } = row;
    result = await write(withoutTitle);
  }
  if (!result.response.ok) throw new Error(result.raw || 'ثبت گزارش تماس ناموفق بود.');

  const parsed = parseJsonSafe(result.raw);
  return Array.isArray(parsed) ? parsed[0] : parsed;
};

const normalizeProviderCallRow = (
  orgId: string,
  serviceId: string,
  item: Record<string, any>
) => {
  const talkSeconds = toIntegerOrNull(firstValue(item.time_talk, item.talk_seconds, item.duration, item.billsec));
  const sourceEndpoint = telefonchyEndpoint(item, 'source');
  const destinationEndpoint = telefonchyEndpoint(item, 'destination');
  const providerDirection = mapDirection(firstValue(item.type, item.direction, item.call_type));
  const direction = isTelefonchyExtensionEndpoint(sourceEndpoint) && isTelefonchyExtensionEndpoint(destinationEndpoint)
    ? 'internal'
    : providerDirection;
  const sourceNumber = normalizePhone(firstValue(item.call_source, item.source_number, item.source, item.from, item.caller));
  const rawDestinationNumber = normalizePhone(firstValue(item.call_dest, item.destination_number, item.destination, item.to, item.callee));
  // An extension is an endpoint, not the recipient's telephone number. This
  // prevents an operator/extension identifier from being shown as a destination phone.
  const destinationNumber = direction === 'outgoing' && isTelefonchyExtensionEndpoint(destinationEndpoint)
    ? ''
    : rawDestinationNumber;
  const exten = item?.exten && typeof item.exten === 'object' && !Array.isArray(item.exten) ? item.exten : {};
  const targetExtension = firstValue(
    item.target_extension,
    item.target_exten,
    item.destination_extension,
    item.destination_exten,
    destinationEndpoint?.extension,
    destinationEndpoint?.number,
    direction === 'incoming' ? exten.number : '',
    isTelefonchyExtensionEndpoint(destinationEndpoint) ? rawDestinationNumber : ''
  );
  const targetEndpointName = firstValue(destinationEndpoint?.name, item.destination_name, item.target_name);
  const operator = resolveTelefonchyOperator(item, direction);
  const counterpartyPhone = direction === 'incoming' ? sourceNumber : destinationNumber;
  const callId = firstValue(item.call_id, item.callId, item.cuid, item.unique_id);
  const fileId = firstValue(item.file_id, item.fileId, item.record_id);
  const recordingAvailable = hasTelefonchyRecording(item, callId, fileId);

  return {
    org_id: orgId,
    provider: 'telefonchy',
    service_id: firstValue(item.service_id, item.serviceId, serviceId) || null,
    call_id: callId || null,
    object_id: firstValue(item.object_id, item.objectId, item.id) || null,
    direction,
    status: mapStatus(firstValue(item.status, item.call_status, item.disposition), talkSeconds),
    source_number: sourceNumber || null,
    destination_number: destinationNumber || null,
    extension: operator.extension || null,
    target_extension: targetExtension || null,
    target_endpoint_name: targetEndpointName || null,
    operator_code: operator.operatorCode || null,
    trunk: firstValue(item.trunk, item.trunk_number) || null,
    started_at: parseTehranProviderDateTimeToUtcIso(firstValue(item.started_at, item.start_at, item.start_time, item.created_at)),
    ended_at: parseTehranProviderDateTimeToUtcIso(firstValue(item.ended_at, item.end_at, item.end_time, item.updated_at)),
    wait_seconds: toIntegerOrNull(firstValue(item.time_wait, item.wait_seconds)),
    talk_seconds: talkSeconds,
    file_id: recordingAvailable ? fileId : null,
    recording_url: firstValue(item.recording_url, item.recordingUrl, item.file_url, item.audio_url) || null,
    title: counterpartyPhone || sourceNumber || destinationNumber || 'تماس VoIP',
    metadata: {
      provider: 'telefonchy',
      action: 'sync_recent_calls',
      build: FUNCTION_BUILD,
      recording_available: recordingAvailable,
      recording_file: recordingAvailable ? firstValue(item.file_record, item.fileRecord, item.recording_file, item.recordingFile) : null,
      provider_operator_name: operator.displayName || null,
      provider_operator_id: operator.providerOperatorId || null,
      provider_source_endpoint_type: firstValue(sourceEndpoint?.type) || null,
      provider_destination_endpoint_type: firstValue(destinationEndpoint?.type) || null,
      provider_row: item,
    },
  };
};

const fetchTelefonchyCalls = async (
  baseUrl: string,
  token: string,
  serviceId: string,
  options?: { perPage?: number; days?: number }
) => {
  const limit = Math.min(Math.max(Number(options?.perPage || 20), 1), 100);
  const days = Math.min(Math.max(Number(options?.days || 7), 1), 90);
  const dateFrom = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
  const dateTo = new Date();
  const calls: any[] = [];
  const rawPages: string[] = [];
  let parsed: any = null;
  let page = 1;
  let lastPage = 1;

  do {
    const providerUrl = new URL(`${baseUrl}/webservice/v1/calls`);
    providerUrl.searchParams.set('service_id', serviceId);
    providerUrl.searchParams.set('page', String(page));
    providerUrl.searchParams.set('sort', 'DESC');
    providerUrl.searchParams.set('date_from', formatTelefonchyJalaliDateTime(dateFrom, '00:00'));
    providerUrl.searchParams.set('date_to', formatTelefonchyJalaliDateTime(dateTo, '23:59'));

    const timeout = createTimeoutSignal(10000);
    let response: Response;
    try {
      response = await fetch(providerUrl.toString(), {
        method: 'GET',
        headers: {
          'webservice-token': token,
          Accept: 'application/json',
        },
        signal: timeout.signal,
      });
    } finally {
      timeout.cleanup();
    }

    const raw = await response.text();
    rawPages.push(raw);
    parsed = parseJsonSafe(raw);
    if (!response.ok) throw new Error(raw || `Telefonchy HTTP ${response.status}`);

    calls.push(...extractCallsArray(parsed));
    const paginator = parsed?.paginator || {};
    lastPage = Math.max(1, Number(paginator.last || paginator.total_pages || page) || page);
    page += 1;
  } while (calls.length < limit && page <= lastPage && page <= 10);

  return {
    raw: rawPages[0] || '',
    parsed,
    calls: calls.slice(0, limit),
  };
};

const reconcileTelefonchyRecordings = async (supabaseUrl: string, serviceRoleKey: string) => {
  const settingsRows = await fetchActiveTelefonchySettings(supabaseUrl, serviceRoleKey);
  const stats = { organizations: 0, fetched: 0, saved: 0, failed: 0 };
  for (const settingsRow of settingsRows) {
    const orgId = firstValue(settingsRow?.org_id);
    const settings = settingsRow?.settings && typeof settingsRow.settings === 'object' ? settingsRow.settings : {};
    const serviceId = firstValue(settings.service_id, Deno.env.get('TELEFONCHY_SERVICE_ID'));
    const token = firstValue(settings.webservice_token, Deno.env.get('TELEFONCHY_WEBSERVICE_TOKEN'));
    if (!orgId || !serviceId || !token) continue;
    stats.organizations += 1;
    try {
      const baseUrl = trimTrailingSlash(firstValue(settings.base_url, Deno.env.get('TELEFONCHY_BASE_URL'), 'https://panel.telefonchy.com'));
      const result = await fetchTelefonchyCalls(baseUrl, token, serviceId, { perPage: 100, days: 2 });
      stats.fetched += result.calls.length;
      for (const item of result.calls) {
        if (!item || typeof item !== 'object') continue;
        const row = normalizeProviderCallRow(orgId, serviceId, item);
        if (!row.call_id && !row.object_id) continue;
        await saveCallLog(supabaseUrl, serviceRoleKey, row);
        stats.saved += 1;
      }
    } catch (error) {
      stats.failed += 1;
      console.warn('[telefonchy-smartcall] recording reconciliation failed', orgId, String((error as any)?.message || error));
    }
  }
  return stats;
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json(405, { success: false, message: 'روش ارسال درخواست معتبر نیست.' });

  const supabaseUrl = Deno.env.get('SUPABASE_URL');
  const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!supabaseUrl || !serviceRoleKey) {
    return json(500, { success: false, message: 'تنظیمات سرور کامل نیست. متغیرهای Supabase را بررسی کنید.' });
  }

  try {
    const authHeader = req.headers.get('Authorization') || '';
    if (!authHeader.startsWith('Bearer ')) {
      return json(401, { success: false, message: 'توکن کاربر ارسال نشده است.' });
    }

    const body = await req.json().catch(() => ({}));
    const action = String(body.action || 'smartcall').trim();
    const requestToken = authHeader.replace(/^Bearer\s+/i, '').trim();
    if (action === 'reconcile_recordings') {
      if (requestToken !== serviceRoleKey) return json(401, { success: false, message: 'دسترسی همگام‌سازی سروری مجاز نیست.' });
      const stats = await reconcileTelefonchyRecordings(supabaseUrl, serviceRoleKey);
      return json(200, { success: true, provider: 'telefonchy', stats });
    }
    const user = await verifyUserToken(supabaseUrl, serviceRoleKey, requestToken);
    const profile = await fetchProfile(supabaseUrl, serviceRoleKey, user.id);
    if (!profile?.id || !profile?.org_id) {
      return json(403, { success: false, message: 'پروفایل سازمانی کاربر برای VoIP کامل نیست.' });
    }

    const settingsRow = await fetchVoipSettings(supabaseUrl, serviceRoleKey, profile.org_id);
    const overrideSettings = body?.overrideSettings && typeof body.overrideSettings === 'object' ? body.overrideSettings : {};
    const hasOverrideSettings = Object.keys(overrideSettings).length > 0;
    const settings = { ...(settingsRow?.settings || {}), ...overrideSettings };
    if (!settingsRow && !hasOverrideSettings) {
      return json(400, { success: false, message: 'اتصال VoIP فعال نیست.' });
    }
    if (settingsRow?.is_active === false && settings.is_active !== true) {
      return json(400, { success: false, message: 'اتصال VoIP فعال نیست.' });
    }

    const to = normalizePhone(firstValue(body.to, body.phone, body.recipient));
    const extension = firstValue(profile.voip_extension, settings.default_extension);
    const serviceId = firstValue(profile.voip_service_id, settings.service_id, Deno.env.get('TELEFONCHY_SERVICE_ID'));
    const token = firstValue(settings.webservice_token, Deno.env.get('TELEFONCHY_WEBSERVICE_TOKEN'));
    const baseUrl = trimTrailingSlash(firstValue(settings.base_url, Deno.env.get('TELEFONCHY_BASE_URL'), 'https://panel.telefonchy.com'));

    if (!serviceId) return json(400, { success: false, message: 'Service ID تلفنچی تنظیم نشده است.' });
    if (!token) return json(400, { success: false, message: 'Webservice Token تلفنچی تنظیم نشده است.' });

    if (action === 'test_connection') {
      const result = await fetchTelefonchyCalls(baseUrl, token, serviceId, { perPage: 1, days: 30 });
      return json(200, {
        success: true,
        message: 'اتصال تلفنچی برقرار است.',
        provider: 'telefonchy',
        sample_count: result.calls.length,
      });
    }

    if (action === 'sync_recent_calls') {
      const perPage = Number(body.perPage || body.per_page || 30);
      const days = Number(body.days || 7);
      const result = await fetchTelefonchyCalls(baseUrl, token, serviceId, { perPage, days });
      let saved = 0;
      for (const item of result.calls) {
        if (!item || typeof item !== 'object') continue;
        const row = normalizeProviderCallRow(profile.org_id, serviceId, item);
        if (!row.call_id && !row.object_id) continue;
        await saveCallLog(supabaseUrl, serviceRoleKey, row);
        saved += 1;
      }

      return json(200, {
        success: true,
        provider: 'telefonchy',
        fetched: result.calls.length,
        saved,
        message: `${saved} تماس از تلفنچی همگام‌سازی شد.`,
      });
    }

    if (profile.voip_enabled !== true) {
      return json(403, { success: false, message: 'VoIP برای این کاربر فعال نیست.' });
    }
    if (settings.smartcall_enabled === false) {
      return json(400, { success: false, message: 'Smart Call در تنظیمات VoIP فعال نیست.' });
    }
    if (!to) return json(400, { success: false, message: 'شماره مقصد تماس مشخص نیست.' });
    if (!extension) return json(400, { success: false, message: 'داخلی VoIP کاربر مشخص نیست.' });

    const providerUrl = new URL(`${baseUrl}/webservice/v1/smartcall`);
    providerUrl.searchParams.set('service_id', serviceId);
    providerUrl.searchParams.set('exten', extension);
    providerUrl.searchParams.set('to', to);

    const timeout = createTimeoutSignal(9000);
    let response: Response;
    try {
      response = await fetch(providerUrl.toString(), {
        method: 'GET',
        headers: {
          'webservice-token': token,
          Accept: 'application/json',
        },
        signal: timeout.signal,
      });
    } finally {
      timeout.cleanup();
    }

    const providerRaw = await response.text();
    const providerJson = parseJsonSafe(providerRaw);
    const baseLogRow = {
      org_id: profile.org_id,
      provider: 'telefonchy',
      service_id: serviceId,
      direction: 'outgoing',
      source_number: extension,
      destination_number: to,
      extension,
      operator_code: firstValue(profile.voip_operator_code) || null,
      related_module_id: firstValue(body.moduleId, body.module_id, body.relatedModuleId, body.related_module_id) || null,
      related_record_id: firstValue(body.recordId, body.record_id, body.relatedRecordId, body.related_record_id) || null,
      assignee_id: profile.id,
      created_by: user.id,
      title: to,
    };

    if (!response.ok) {
      await insertCallLog(supabaseUrl, serviceRoleKey, {
        ...baseLogRow,
        status: 'failed',
        metadata: {
          action: 'smartcall',
          build: FUNCTION_BUILD,
          provider_status: response.status,
          provider_response: providerJson || providerRaw,
        },
      }).catch((error) => console.warn('[telefonchy-smartcall] failed-log:error', String(error?.message || error)));
      return json(502, { success: false, message: providerRaw || `Telefonchy HTTP ${response.status}` });
    }

    const ids = extractProviderIds(providerJson);
    const callLog = await saveCallLog(supabaseUrl, serviceRoleKey, {
      ...baseLogRow,
      call_id: ids.callId || null,
      object_id: ids.objectId || null,
      status: 'ringing',
      started_at: new Date().toISOString(),
      metadata: {
        action: 'smartcall',
        build: FUNCTION_BUILD,
        provider_response: providerJson || providerRaw,
      },
    });

    return json(200, {
      success: true,
      provider: 'telefonchy',
      call_log_id: callLog?.id || null,
      provider_result: providerJson || providerRaw,
    });
  } catch (error: any) {
    console.error('[telefonchy-smartcall] error', String(error?.message || error));
    return json(400, { success: false, message: String(error?.message || 'شروع تماس VoIP ناموفق بود.') });
  }
});
