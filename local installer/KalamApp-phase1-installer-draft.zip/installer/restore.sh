#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"; cd "$ROOT"
ENV_FILE="${KALAMAPP_ENV_FILE:-$HOME/.config/kalamapp/customer.env}"
[[ -f "$ENV_FILE" ]] || { echo "Missing environment file: $ENV_FILE" >&2; exit 2; }
[[ $# -eq 1 && -d "$1" ]] || { echo 'Usage: restore.sh BACKUP_DIRECTORY' >&2; exit 2; }
BACKUP="$(realpath "$1")"
(cd "$BACKUP" && sha256sum -c SHA256SUMS)
printf 'Restore overwrites data in this dedicated database. Type RESTORE-TO-DEDICATED-DATABASE to continue: '
read -r answer
[[ "$answer" == 'RESTORE-TO-DEDICATED-DATABASE' ]] || { echo 'Cancelled.'; exit 1; }
compose(){ docker compose --env-file "$ENV_FILE" -f docker/docker-compose.customer.yml "$@"; }
mapfile -t app_services < <(compose ps --services --filter status=running | grep -vx db || true)
restart(){ compose up -d; }
trap restart EXIT
if ((${#app_services[@]})); then compose stop "${app_services[@]}"; fi
compose exec -T db pg_restore --clean --if-exists -U postgres -d postgres < "$BACKUP/database.dump"
tar -xzf "$BACKUP/storage.tar.gz" -C docker
compose up -d
trap - EXIT
echo 'Database and storage restore completed. Validate sign-in, records, files, and Edge Functions before serving traffic.'
