#!/usr/bin/env bash
set -u
ROOT="$(cd "$(dirname "$0")" && pwd)"; cd "$ROOT"
ENV_FILE="${KALAMAPP_ENV_FILE:-$HOME/.config/kalamapp/customer.env}"
[[ -f "$ENV_FILE" ]] || { echo "FAIL: missing environment file: $ENV_FILE"; exit 2; }
compose(){ docker compose --env-file "$ENV_FILE" -f docker/docker-compose.customer.yml "$@"; }
status=0
if rows="$(compose ps --format json 2>/dev/null)"; then
  printf '%s\n' "$rows" | python3 -c 'import json,sys
s=sys.stdin.read().strip()
try:
 data=json.loads(s); data=data if isinstance(data,list) else [data]
except Exception:
 data=[json.loads(x) for x in s.splitlines() if x.strip()]
rows={str(x.get("Service",x.get("service",""))):x for x in data}
required=("customer-frontend","db","auth","rest","realtime","storage","functions")
failed=False
for name in required:
 x=rows.get(name)
 if not x: print(f"FAIL {name}: not found"); failed=True; continue
 state=str(x.get("State",x.get("state","unknown"))).lower()
 health=str(x.get("Health",x.get("health",""))).lower()
 label=health or "no-healthcheck"
 ok=state=="running" and (not health or health=="healthy")
 print(("PASS" if ok else "FAIL")+f" {name}: state={state} health={label}")
 failed |= not ok
sys.exit(1 if failed else 0)' || status=1
else echo 'FAIL: Compose status unavailable'; status=1; fi
port_binding="$(compose port customer-frontend 80 2>/dev/null || true)"; port="${port_binding##*:}"
if [[ -n "$port" ]] && curl -fsS "http://127.0.0.1:$port/health" >/dev/null 2>&1; then echo 'PASS frontend HTTP'; else echo 'FAIL frontend HTTP'; status=1; fi
for path in "$ROOT/docker/volumes/db/data" "$ROOT/docker/volumes/storage"; do
  mkdir -p "$path"
  usage="$(df -P "$path" | awk 'END {print $5}')"
  echo "DISK $path used=${usage:-unknown}"
  pct="${usage%%%}"
  if [[ "$pct" =~ ^[0-9]+$ ]] && ((pct >= 90)); then echo "WARN disk usage at or above 90%: $path"; fi
done
external="$(python3 - "$ENV_FILE" <<'PY'
import sys
from pathlib import Path
for line in Path(sys.argv[1]).read_text(encoding='utf-8').splitlines():
 if line.startswith('EXTERNAL_HEALTH_CHECK_URLS='):
  print(line.split('=',1)[1].strip().strip('"'))
PY
)"
if [[ -z "$external" ]]; then echo 'EXTERNAL checks: not configured'; else
  IFS=',' read -r -a urls <<< "$external"
  for url in "${urls[@]}"; do
    code="$(curl -sS -o /dev/null -w '%{http_code}' --max-time 8 "$url" 2>/dev/null || true)"
    if [[ "$code" != 000 && "$code" -lt 500 ]]; then echo 'EXTERNAL available'; else echo 'EXTERNAL unavailable'; fi
  done
fi
exit "$status"
