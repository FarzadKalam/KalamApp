#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
ENV_FILE="${KALAMAPP_ENV_FILE:-$HOME/.config/kalamapp/customer.env}"
if [[ ! -f "$ENV_FILE" ]]; then
  mkdir -p "$(dirname "$ENV_FILE")"; install -m 600 config/customer.env.example "$ENV_FILE"
  echo "Created secret-free config template outside the repository: $ENV_FILE"
  echo 'Set CUSTOMER_PUBLIC_URL to the final HTTPS origin, then rerun this installer.'
  exit 2
fi
"$ROOT/scripts/validate-environment.sh" "$ENV_FILE"
"$ROOT/scripts/generate-secrets.sh" "$ENV_FILE"
docker compose --env-file "$ENV_FILE" -f docker/docker-compose.customer.yml config -q
printf 'This will pull images and start the dedicated KalamApp/Supabase stack. Type START CUSTOMER INSTANCE to continue: '
read -r answer
[[ "$answer" == 'START CUSTOMER INSTANCE' ]] || { echo 'Cancelled.'; exit 1; }
docker compose --env-file "$ENV_FILE" -f docker/docker-compose.customer.yml pull
docker compose --env-file "$ENV_FILE" -f docker/docker-compose.customer.yml up -d
