#!/usr/bin/env bash
set -euo pipefail
cat <<'MSG'
BLOCKED: no approved clean-install migration manifest is included yet.
This project has hundreds of SQL files, duplicate phase numbers, and a separate full-schema bootstrap.
Do not apply SQL by filename sorting alone. Use --inventory to list candidate filenames only.
An owner-reviewed explicit migration order and clean-database test are required before applying anything.
MSG
if [[ "${1:-}" == --inventory ]]; then
  ROOT="$(cd "$(dirname "$0")/.." && pwd)"
  find "$ROOT" -maxdepth 1 -type f -name 'database_v1*.sql' -printf '%f\n' | sort -V
  exit 0
fi
exit 3
