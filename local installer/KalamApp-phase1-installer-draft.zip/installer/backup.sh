#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"; cd "$ROOT"
ENV_FILE="${KALAMAPP_ENV_FILE:-$HOME/.config/kalamapp/customer.env}"
[[ -f "$ENV_FILE" ]] || { echo "Missing environment file: $ENV_FILE" >&2; exit 2; }
OUT="${1:-$HOME/.local/share/kalamapp/backups}"
mkdir -p "$OUT"; chmod 700 "$OUT"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"; TMP="$OUT/.backup-$STAMP.tmp"; mkdir -m 700 "$TMP"
cleanup(){ rm -rf "$TMP"; }; trap cleanup ERR
# Secrets are not included. Preserve config only as a names-only redacted reference.
docker compose --env-file "$ENV_FILE" -f docker/docker-compose.customer.yml exec -T db pg_dump -U postgres -d postgres -Fc > "$TMP/database.dump"
mkdir -p docker/volumes/storage
tar -C docker -czf "$TMP/storage.tar.gz" volumes/storage
python3 - "$ENV_FILE" "$TMP/config-key-names.txt" "$TMP/config-redacted.env" <<'PY'
import re,sys
from pathlib import Path
names=[]
safe=[]
secret=re.compile(r'(PASSWORD|SECRET|TOKEN|_KEY(?:_|$)|ACCESS_KEY|CREDENTIAL|PRIVATE|DATABASE|DB_URL|DSN|CONNECTION_STRING)',re.I)
for line in Path(sys.argv[1]).read_text(encoding='utf-8').splitlines():
 m=re.match(r'^([A-Z][A-Z0-9_]*)=',line)
 if m:
  key,value=line.split('=',1); names.append(key)
  embedded_credential='://' in value and '@' in value
  token_query=('?' in value and re.search(r'(URI|URL|DSN|CONNECTION)',key,re.I))
  safe.append(key+'=' if secret.search(key) or embedded_credential or token_query else line)
Path(sys.argv[2]).write_text('\n'.join(names)+'\n',encoding='utf-8',newline='\n')
Path(sys.argv[3]).write_text('\n'.join(safe)+'\n',encoding='utf-8',newline='\n')
PY
printf 'created_utc=%s\n' "$STAMP" > "$TMP/metadata.txt"
du -b "$TMP/database.dump" "$TMP/storage.tar.gz" > "$TMP/sizes.txt"
(cd "$TMP" && sha256sum database.dump storage.tar.gz config-key-names.txt config-redacted.env metadata.txt sizes.txt > SHA256SUMS)
FINAL="$OUT/kalamapp-backup-$STAMP"; mv "$TMP" "$FINAL"; trap - ERR
chmod -R go-rwx "$FINAL"; echo "Backup created: $FINAL (secret values excluded)"
