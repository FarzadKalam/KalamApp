// This token is stamped with the application version during every production build.
// A release must never reuse caches that contain hashed assets from an older build.
const CACHE_VERSION = '__TAZESYSTEM_CACHE_VERSION__';
const SHELL_CACHE = `tazesystem-shell-${CACHE_VERSION}`;
const PAGE_CACHE = `tazesystem-pages-${CACHE_VERSION}`;
const ASSET_CACHE = `tazesystem-assets-${CACHE_VERSION}`;
const DATA_CACHE = `tazesystem-data-${CACHE_VERSION}`;
const ALL_CACHES = [SHELL_CACHE, PAGE_CACHE, ASSET_CACHE, DATA_CACHE];
const VERSION_MANIFEST_PATH = '/version.json';
const RUNTIME_CONFIG_PATH = '/kalamapp-runtime-config.js';
const CENTRAL_RELEASE_PATH = '/central-release.json';

const APP_SHELL = [
  '/index.html',
  '/manifest.webmanifest',
  '/apple-touch-icon.png',
  '/pwa-192x192.png',
  '/pwa-512x512.png',
  '/maskable-512x512.png',
  '/favicon.svg',
  '/favicon.png?v=f01',
  '/manifest.webmanifest?v=f01',
  '/apple-touch-icon.png?v=f01',
  '/pwa-192x192.png?v=f01',
  '/pwa-512x512.png?v=f01',
  '/maskable-512x512.png?v=f01',
  '/brand/taze-system-logo-f01.webp',
  '/brand/taze-system-hero-f01.webp',
];

const MAX_PAGE_ENTRIES = 20;
const MAX_ASSET_ENTRIES = 80;
const MAX_DATA_ENTRIES = 40;

const SHARE_DB_NAME = 'tazesystem-share-db';
const SHARE_STORE_NAME = 'shared_inbox';
const SHARE_DB_VERSION = 1;

const openShareDb = () =>
  new Promise((resolve, reject) => {
    const request = indexedDB.open(SHARE_DB_NAME, SHARE_DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(SHARE_STORE_NAME)) {
        db.createObjectStore(SHARE_STORE_NAME, { keyPath: 'id' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('Could not open share db'));
  });

const saveSharedPayload = async (payload) => {
  const db = await openShareDb();
  try {
    await new Promise((resolve, reject) => {
      const tx = db.transaction(SHARE_STORE_NAME, 'readwrite');
      const store = tx.objectStore(SHARE_STORE_NAME);
      store.put(payload);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error || new Error('Could not save share payload'));
      tx.onabort = () => reject(tx.error || new Error('Share payload transaction aborted'));
    });
  } finally {
    db.close();
  }
};

const fileToBase64 = (file) =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(reader.error || new Error('Could not read shared file'));
    reader.readAsDataURL(file);
  });

const handleShareTargetPost = async (request) => {
  const formData = await request.formData();
  const files = [];

  for (const value of formData.getAll('files')) {
    if (!(value instanceof File)) continue;
    const base64 = await fileToBase64(value);
    files.push({
      name: String(value.name || 'shared-file').trim() || 'shared-file',
      type: String(value.type || 'application/octet-stream').trim() || 'application/octet-stream',
      size: Number(value.size || 0),
      lastModified: Number(value.lastModified || Date.now()),
      dataBase64: base64,
    });
  }

  const shareId = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

  await saveSharedPayload({
    id: shareId,
    title: String(formData.get('title') || '').trim(),
    text: String(formData.get('text') || '').trim(),
    url: String(formData.get('url') || '').trim(),
    files,
    createdAt: Date.now(),
  });

  return Response.redirect(`/share-target?share_id=${encodeURIComponent(shareId)}`, 303);
};

const shouldHandleRequest = (requestUrl, request) => {
  if (request.method !== 'GET') return false;
  if (requestUrl.origin !== self.location.origin) return false;
  if (requestUrl.pathname.startsWith('/api/')) return false;
  if (request.headers.has('range')) return false;
  return true;
};

const shouldCacheResponse = (response) => {
  if (!response) return false;
  if (response.status === 206) return false;
  if (response.type === 'error') return false;
  return response.ok || response.type === 'opaque';
};

const buildUnavailableJsonResponse = (message, status = 503) =>
  new Response(JSON.stringify({ error: message }), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store, no-cache, must-revalidate, max-age=0',
      Pragma: 'no-cache',
    },
  });

const buildStaticAssetFallbackResponse = (status = 504) =>
  new Response('', {
    status,
    headers: {
      'Cache-Control': 'no-store',
    },
  });

const waitForRetry = (milliseconds) => new Promise((resolve) => {
  setTimeout(resolve, milliseconds);
});

const limitCacheEntries = async (cacheName, maxEntries) => {
  const cache = await caches.open(cacheName);
  const keys = await cache.keys();
  if (keys.length <= maxEntries) return;
  const overflow = keys.length - maxEntries;
  await Promise.all(keys.slice(0, overflow).map((request) => cache.delete(request)));
};

const putInCache = async (cacheName, request, response, maxEntries) => {
  if (!shouldCacheResponse(response)) return response;
  try {
    const cache = await caches.open(cacheName);
    await cache.put(request, response.clone());
    if (maxEntries) {
      await limitCacheEntries(cacheName, maxEntries);
    }
  } catch {
    // Cache Storage is an optional acceleration layer. A broken or interrupted
    // cache write must never reject the user request or create console noise.
  }
  return response;
};

const matchShell = () => caches.match('/index.html', { ignoreSearch: true });

const isStaticAssetRequest = (requestUrl, request) => {
  if ([VERSION_MANIFEST_PATH, RUNTIME_CONFIG_PATH, CENTRAL_RELEASE_PATH].includes(requestUrl.pathname)) return false;
  if (requestUrl.pathname.startsWith('/assets/')) return true;
  if (requestUrl.pathname.startsWith('/font/')) return true;
  if (requestUrl.pathname.startsWith('/calendar/')) return true;
  if (requestUrl.pathname.endsWith('.json')) return true;
  return ['style', 'script', 'font', 'image', 'worker'].includes(request.destination);
};

const isImmutableBuildAssetRequest = (requestUrl) => requestUrl.pathname.startsWith('/assets/');

const handleNavigationRequest = async (event) => {
  try {
    const preloadedResponse = await event.preloadResponse;
    if (preloadedResponse) {
      void putInCache(PAGE_CACHE, event.request, preloadedResponse.clone(), MAX_PAGE_ENTRIES);
      return preloadedResponse;
    }

    const networkResponse = await fetch(event.request);
    void putInCache(PAGE_CACHE, event.request, networkResponse.clone(), MAX_PAGE_ENTRIES);
    return networkResponse;
  } catch {
    const cachedPage = await caches.match(event.request, { ignoreSearch: true });
    if (cachedPage) return cachedPage;
    const shell = await matchShell();
    if (shell) return shell;
    throw new Error('Navigation failed and no cached shell is available.');
  }
};

const handleStaticAssetRequest = async (request) => {
  const requestUrl = new URL(request.url);
  const cached = await caches.match(request, { ignoreSearch: false });

  if (cached && isImmutableBuildAssetRequest(requestUrl)) {
    return cached;
  }

  const fetchFromNetwork = async () => {
    // درخواست chunkهای برنامه در اتصال‌های ناپایدار گاهی بدون پاسخ قطع می‌شود.
    // یک تلاش کوتاهِ دوم، بدون تأخیر برای پاسخ‌های معتبر یا استفاده از cache،
    // جلوی خطای «dynamic import» را می‌گیرد.
    for (let attempt = 0; attempt < 2; attempt += 1) {
      try {
        const response = await fetch(request);
        if (response.ok || response.status < 500 || attempt === 1) {
          return putInCache(ASSET_CACHE, request, response, MAX_ASSET_ENTRIES);
        }
      } catch {
        // تلاش دوم فقط برای شکست‌های گذرای شبکه انجام می‌شود.
      }
      await waitForRetry(300);
    }
    return undefined;
  };

  const networkPromise = fetchFromNetwork();

  if (cached) {
    void networkPromise;
    return cached;
  }

  const networkResponse = await networkPromise;
  if (networkResponse) return networkResponse;
  return buildStaticAssetFallbackResponse();
};

const handleDataRequest = async (request) => {
  try {
    const networkResponse = await fetch(request);
    void putInCache(DATA_CACHE, request, networkResponse.clone(), MAX_DATA_ENTRIES);
    return networkResponse;
  } catch {
    const cached = await caches.match(request, { ignoreSearch: false });
    if (cached) return cached;
    return buildUnavailableJsonResponse('network_unavailable');
  }
};

const handleVersionManifestRequest = async (request) => {
  try {
    const response = await fetch(request, { cache: 'no-store' });
    const headers = new Headers(response.headers);
    headers.set('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
    headers.set('Pragma', 'no-cache');

    const normalizedResponse = new Response(response.body, {
      status: response.status,
      statusText: response.statusText,
      headers,
    });

    return normalizedResponse;
  } catch {
    return buildUnavailableJsonResponse('version_manifest_unavailable');
  }
};

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(SHELL_CACHE).then((cache) => cache.addAll(APP_SHELL)).catch(() => undefined)
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(keys.filter((key) => !ALL_CACHES.includes(key)).map((key) => caches.delete(key)));

      if ('navigationPreload' in self.registration) {
        await self.registration.navigationPreload.enable();
      }

      await self.clients.claim();
    })()
  );
});

self.addEventListener('message', (event) => {
  if (event.data?.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});

self.addEventListener('push', (event) => {
  event.waitUntil((async () => {
    const visibleClients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    if (visibleClients.some((client) => client.visibilityState === 'visible')) return;

    let payload = {};
    try {
      payload = event.data?.json() || {};
    } catch {
      payload = { body: event.data?.text() || '' };
    }
    const title = String(payload.title || 'پیام جدید در تازه سیستم').trim();
    const body = String(payload.body || 'برای مشاهده جزئیات، سامانه را باز کنید.').trim();
    const targetUrl = String(payload.url || '/messages?tab=notes&conversation=system');
    await self.registration.showNotification(title, {
      body,
      icon: '/pwa-192x192.png?v=f01',
      dir: 'rtl',
      lang: 'fa-IR',
      tag: String(payload.tag || payload.eventKey || 'tazesystem-system-message'),
      renotify: true,
      timestamp: Number(payload.timestamp || Date.now()),
      data: { url: targetUrl },
      actions: [{ action: 'open', title: 'مشاهده' }],
    });
  })());
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const targetUrl = new URL(String(event.notification.data?.url || '/messages?tab=notes&conversation=system'), self.location.origin).href;
  event.waitUntil((async () => {
    const clients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    const matchingClient = clients.find((client) => client.url.startsWith(self.location.origin));
    if (matchingClient) {
      await matchingClient.focus();
      if ('navigate' in matchingClient) await matchingClient.navigate(targetUrl);
      return;
    }
    await self.clients.openWindow(targetUrl);
  })());
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  const requestUrl = new URL(request.url);

  if (request.method === 'POST' && requestUrl.origin === self.location.origin && requestUrl.pathname === '/share-target') {
    event.respondWith(handleShareTargetPost(request));
    return;
  }

  if (!shouldHandleRequest(requestUrl, request)) return;

  if ([VERSION_MANIFEST_PATH, RUNTIME_CONFIG_PATH, CENTRAL_RELEASE_PATH].includes(requestUrl.pathname)) {
    event.respondWith(handleVersionManifestRequest(request));
    return;
  }

  if (request.mode === 'navigate') {
    event.respondWith(handleNavigationRequest(event));
    return;
  }

  if (isStaticAssetRequest(requestUrl, request)) {
    event.respondWith(handleStaticAssetRequest(request));
    return;
  }

  event.respondWith(handleDataRequest(request));
});
